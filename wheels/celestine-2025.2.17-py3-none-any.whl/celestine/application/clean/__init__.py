""""""

from celestine.session.session import SuperSession


class Session(SuperSession):
    """"""
