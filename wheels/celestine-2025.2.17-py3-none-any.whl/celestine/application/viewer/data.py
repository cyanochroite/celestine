"""A place to store constants and other application wide information."""

DIRECTORY = "directory"
