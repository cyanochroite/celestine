"""Removes unused imports and unused variables."""

from celestine.package import Abstract
from celestine.typed import N


class Package(Abstract):
    """"""


def run() -> N:
    """"""
