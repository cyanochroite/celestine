"""Blender type is bpy.types.Object."""

from .spawn import _real


class _object(_real):
    """Object data-block defining an object in a scene."""
