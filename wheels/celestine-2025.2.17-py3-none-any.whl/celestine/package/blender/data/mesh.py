"""Blender type is bpy.types.Mesh."""

from .spawn import _real


class _mesh(_real):
    """Mesh data-block defining geometric surfaces."""
