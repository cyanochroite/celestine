"""Blender type is bpy.types.Camera."""

from .spawn import _real


class _camera(_real):
    """Camera data-block for storing camera settings."""
