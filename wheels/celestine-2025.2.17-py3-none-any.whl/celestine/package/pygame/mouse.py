""""""

from celestine.data import wrapper
from celestine.typed import (
    TZ2,
    R,
)


@wrapper(__name__)
def get_pos(**star: R) -> TZ2:
    """"""
    raise NotImplementedError()
