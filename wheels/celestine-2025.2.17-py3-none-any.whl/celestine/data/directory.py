""""""

APPLICATION = "application"
BLENDER = "blender"
CONFIGURATION = "configuration"
DIRECTORY = "directory"
INTERFACE = "interface"
LANGUAGE = "language"
